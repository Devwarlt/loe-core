﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Xml.Linq;

namespace LoESoft.Launcher.Http
{
    public enum PacketID : int
    {
        LOGIN = 1,
        LOGIN_TOKEN = 2,
        REGISTER = 3,
        CHECK_VERSION = 4
    }

    public struct HttpEngineQuery
    {
        public int Length => Objects?.Count ?? 0;

        public Dictionary<string, object> Objects { get; set; }

        public object this[string query] => Objects[query];

        public void AddQuery(string key, object value)
        {
            if (Objects == null)
                Objects = new Dictionary<string, object>();

            Objects.Add(key, value);
        }
    }

    public class HttpEngine
    {
        private WebClient WebClient { get; set; }
        private string Request { get; set; }

        private bool Downloaded { get; set; }

        public static void Handle(PacketID packet, HttpEngineQuery query, Action<string> success, Action<string> error, Action<string> info = null)
        {
            if (!Enum.IsDefined(typeof(PacketID), packet))
            {
                GameLauncher.Warn($"Packet ID '({(int)packet}){packet}' doesn't exist.");
                return;
            }

            try { CreateRequest(packet).SendRequest(query, success, error, info); }
            catch (Exception e) { GameLauncher.Error(e); }
        }

        public static HttpEngine CreateRequest(PacketID packetID)
        {
            var engine = new HttpEngine
            {
                WebClient = new WebClient(),
                Request = $"/?PID={(int)packetID}"
            };
            return engine;
        }

        public void SendRequest(HttpEngineQuery query, Action<string> success, Action<string> error, Action<string> info)
        {
            var sb = new StringBuilder();
            var i = 0;

            foreach (var q in query.Objects)
            {
                sb.Append($"{q.Key}={q.Value}{(i != query.Length - 1 ? "&" : "")}");
                i++;
            }

            string requestURI = $"{GameLauncherParameters.SERVER}{Request}&{sb.ToString()}";

            GameLauncher.Info($"Sending Request {requestURI}");

            try
            {
                var data = WebClient.DownloadString(requestURI);

                if (data.Substring(0, 7) == "<Error>")
                {
                    error?.Invoke(XElement.Parse(data).Value);
                    return;
                }

                if (data.Substring(0, 9) == "<Success>")
                {
                    success?.Invoke(XElement.Parse(data).Value);
                    return;
                }

                // General web feedback data.
                info?.Invoke(data);
            }
            catch { error?.Invoke("Server seems to be offline. Try again later."); }
        }
    }
}