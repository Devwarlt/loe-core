﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LoESoft - Game Launcher")]
[assembly: AssemblyProduct("GameLauncher")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("A BRME game launcher application.")]
[assembly: AssemblyCompany("LoESoft Games")]
[assembly: AssemblyCopyright("Copyright © LoESoft Games 2018")]
[assembly: AssemblyTrademark("BRME")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4ff98f6c-23a1-40a3-8c76-e4ab29bcaab1")]
[assembly: AssemblyVersion("0.1.5")]
[assembly: AssemblyFileVersion("0.1.5")]
[assembly: NeutralResourcesLanguage("en-US")]