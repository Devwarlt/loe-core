﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LoESoft - GameWebServer")]
[assembly: AssemblyProduct("GameWebServer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("A BRME game web server application.")]
[assembly: AssemblyCompany("LoESoft Games")]
[assembly: AssemblyCopyright("Copyright © LoESoft Games 2018")]
[assembly: AssemblyTrademark("BRME")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("80b43be5-185b-4403-8a69-e47cb9b5581e")]
[assembly: AssemblyVersion("0.1.5")]
[assembly: AssemblyFileVersion("0.1.5")]
[assembly: NeutralResourcesLanguage("en-US")]